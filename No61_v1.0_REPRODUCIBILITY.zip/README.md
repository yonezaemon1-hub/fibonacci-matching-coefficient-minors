# No.61 v1.0 reproducibility

**Certified Low-Degree Coefficient-Minor Positivity for Fibonacci Matching Transforms**

Ryutaro Yonezu (Independent Researcher). Preprint v1.0, 2026-11-10.

The computer-assisted theorem establishes strict positivity of the specified adjacent coefficient minors for integer k from 3 to 180, every integer n at least 2k+4, and every minor index r from 0 to k. The general all-k statement is unproved and the original Elizalde, Rivera Jr., and Zhuang Conjecture 4.6 remains unsolved.

Independent AI mathematical and editorial audits reported PASS within their reviewed scope. Novelty is INCONCLUSIVE. Human peer review was not performed.

Verify the archive-level inventory with SHA256SUMS.txt. On systems with sha256sum, run the following command from the extracted archive root.

    sha256sum -c SHA256SUMS.txt

The 23 entries in repro/ are the byte-identical files from the audited REV2 archive. Their candidate labels record the provenance of the frozen files. The v1.0 publication uses these same verifiers and logs. See repro/README.txt for quick checks and full certificate regeneration. The frozen scripts use Python's standard library. The PowerShell runner documents the intended command and runtime requirements.

WINDOWS_REPRO_EVIDENCE_SANITIZED.txt summarizes the supplied Windows run. All 12 intervals covering k=3..180 were regenerated and the full runner and original checksum checks passed. The certificate contained 8,053,165 Newton coefficients (8,036,344 positive, 16,821 zero, and none negative).

Copyright (c) 2026 Ryutaro Yonezu. All rights reserved.
