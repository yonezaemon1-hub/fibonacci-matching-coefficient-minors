#!/usr/bin/env python3
"""Independently check coverage and arithmetic of exact Newton logs.
This validates that the logs are self-consistent, not the proof arithmetic;
for proof regeneration run verify_newton_v023.py over the same ranges.
"""
from pathlib import Path
import re
import argparse

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--k-end', type=int, default=180)
    args=ap.parse_args()
    folder=Path(__file__).resolve().parent
    files=[]
    for fn in folder.glob('NEWTON_LOG_*_*.txt'):
        m=re.fullmatch(r'NEWTON_LOG_(\d+)_(\d+)\.txt',fn.name)
        if m and int(m.group(1))<=args.k_end:
            assert int(m.group(2))<=args.k_end,(fn,'overlaps requested scope')
            files.append((int(m.group(1)),int(m.group(2)),fn))
    files.sort()
    assert files, 'no logs'
    next_k=3
    totals=dict(raw=0,boundary=0,positive=0,zero=0)
    for lo,hi,f in files:
        assert lo==next_k,('gap or overlap',next_k,lo,f)
        next_k=hi+1
        s=f.read_text()
        assert f'PASS exact Newton coefficients, k={lo}..{hi}' in s,f
        assert 'NEGATIVE 0' in s,f
        pairs=dict(re.findall(r'^(RAW_PREFIX_COEFFICIENTS|BOUNDARY_COEFFICIENTS)\s+(\d+)\s*$',s,re.M))
        m2=re.search(r'^POSITIVE\s+(\d+)\s+ZERO\s+(\d+)\s+NEGATIVE\s+0\s*$',s,re.M)
        assert m2 is not None,f
        pairs['POSITIVE'],pairs['ZERO']=m2.groups()
        assert len(pairs)==4,f
        expected_raw=sum(k*(4*k+1) for k in range(lo,hi+1))
        expected_boundary=sum(3*(4*k+1) for k in range(lo,hi+1))
        assert int(pairs['RAW_PREFIX_COEFFICIENTS'])==expected_raw,f
        assert int(pairs['BOUNDARY_COEFFICIENTS'])==expected_boundary,f
        assert int(pairs['POSITIVE'])+int(pairs['ZERO'])==expected_raw+expected_boundary,f
        for a,b in [('raw','RAW_PREFIX_COEFFICIENTS'),('boundary','BOUNDARY_COEFFICIENTS'),('positive','POSITIVE'),('zero','ZERO')]:
            totals[a]+=int(pairs[b])
    assert next_k==args.k_end+1,(next_k,args.k_end)
    print('PASS: contiguous complete Newton log coverage k=3..%d, log chunks=%d'%(args.k_end,len(files)))
    print('TOTAL',totals['raw']+totals['boundary'], 'POSITIVE',totals['positive'],'ZERO',totals['zero'],'NEGATIVE 0')
    print('RAW_PREFIX',totals['raw'],'BOUNDARY',totals['boundary'])
    print('LIMITATION: this script checks logs only; run the original Newton verifier for independent regeneration.')

if __name__=='__main__':main()
