#!/usr/bin/env python3
"""Standalone direct Newton verifier for No.61 original left minors.

Constructs A=Z_{k+1}Z_{k+3}p_{n,k}^2 and B=Z_{k+2}^2p_{n,k-1}p_{n,k+1}
straight from their binomial-sum definitions.  It does not use the
one-factor reduction, its H1/H2 premises, or the v0.23 verifier.

For each selected fixed k, the exact minor is a polynomial in
s=n-2*k-4 of degree at most 4*k.  Nonnegative Newton coefficients and
strictly positive constant term prove positivity for every integer s>=0.

This checker can be expensive for large k.  Its default 3..12 is a
smoke test; run --k-end 22 to reproduce the bundled direct audit.
"""
import argparse
from math import comb


def choose(n, r):
    return comb(n, r) if 0 <= r <= n else 0


def matching(m):
    # Direct matching-binomial formula, not a recurrence from the frozen code.
    return [choose(m-j, j) for j in range(m//2+1)]


def tiles_bigdesc(n, k):
    return [choose(k+2-j, j) * choose(n-k-2+j, k)
            for j in range((k+2)//2+1)]


def product_truncated(factors, limit):
    poly = [1]
    for factor in factors:
        out = [0] * min(limit+1, len(poly)+len(factor)-1)
        for i, a in enumerate(poly):
            if a == 0: continue
            for j, b in enumerate(factor[:max(0, limit+1-i)]):
                if i+j < len(out):
                    out[i+j] += a*b
        poly = out
    return poly + [0] * (limit+1-len(poly))


def minors_at(k, s):
    n = 2*k + 4 + s
    a = product_truncated([matching(k+1), matching(k+3),
                            tiles_bigdesc(n,k), tiles_bigdesc(n,k)], k+1)
    b = product_truncated([matching(k+2), matching(k+2),
                            tiles_bigdesc(n,k-1), tiles_bigdesc(n,k+1)], k+1)
    return [a[r]*b[r+1] - a[r+1]*b[r] for r in range(k+1)]


def newton_coeffs(samples):
    work = list(samples)
    out = []
    while work:
        out.append(work[0])
        work = [work[i+1]-work[i] for i in range(len(work)-1)]
    return out


def certify(k):
    data = [[] for _ in range(k+1)]
    # 4k+2 values suffice to verify Delta^(4k+1) = 0.
    for s in range(4*k+2):
        row = minors_at(k,s)
        for r, value in enumerate(row): data[r].append(value)
    counts = [0,0]
    for r, values in enumerate(data):
        coeffs = newton_coeffs(values)
        assert coeffs[0] > 0, (k,r,'not strictly positive at s=0')
        assert coeffs[-1] == 0, (k,r,'degree exceeds 4k')
        for j,x in enumerate(coeffs[:-1]):
            assert x >= 0, (k,r,j,'NEGATIVE',x)
            counts[x==0] += 1
    return counts


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--k-start',type=int,default=3)
    ap.add_argument('--k-end',type=int,default=12)
    args=ap.parse_args()
    ap.error('require 3<=k-start<=k-end') if (args.k_start<3 or args.k_end<args.k_start) else None
    positive=zero=0
    for k in range(args.k_start,args.k_end+1):
        p,z=certify(k)
        positive+=p; zero+=z
    assert positive+zero == sum((k+1)*(4*k+1) for k in range(args.k_start,args.k_end+1))
    print('PASS: direct ORIGINAL minors, exact Newton certificate, k=%d..%d' % (args.k_start,args.k_end))
    print('POSITIVE',positive,'ZERO',zero,'NEGATIVE',0)
    print('SCOPE: every integer n>=2*k+4 and every r=0..k, for the stated finite k only')
    print('METHOD: A,B from definitions; NO one-factor reduction or H1/H2')
    print('NOT CERTIFIED: all k, original Conjecture 4.6, novelty, Windows')

if __name__ == '__main__':main()
