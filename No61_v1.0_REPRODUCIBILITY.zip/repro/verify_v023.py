#!/usr/bin/env python3
"""Exact integer verification of No.61 v0.23. Does not prove all k,n."""
from math import comb
import argparse

def C(a,b): return comb(a,b) if 0<=b<=a else 0

def z(m): return [C(m-j,j) for j in range(m//2+1)]

def p(n,k): return [C(k+2-j,j)*C(n-k-2+j,k) for j in range((k+2)//2+1)]

def at_convolution(a,b,r):
    return sum(a[i]*b[r-i] for i in range(max(0,r+1-len(b)),min(r+1,len(a))))

def mul(a,b):
    result=[0]*(len(a)+len(b)-1)
    for i,ai in enumerate(a):
        for j,bj in enumerate(b): result[i+j]+=ai*bj
    return result

def at(a,i): return a[i] if 0<=i<len(a) else 0

def M(X,Y,r): return at(X,r)*at(Y,r+1)-at(X,r+1)*at(Y,r)

def boundary(n,k):
    a=p(n,k); low=p(n,k-1); high=p(n,k+1)
    pp=[at_convolution(a,a,r) for r in (k-1,k,k+1)]
    qq=[at_convolution(low,high,r) for r in (k-1,k,k+1)]
    p1,p0,pplus=pp; q1,q0,qplus=qq
    D=p0*qplus-pplus*q0
    X=p1*qplus-pplus*q1
    H=p1*q0-p0*q1
    return D,X,H

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--extended',action='store_true')
    args=ap.parse_args()
    total=0
    for s in (0,1,4,10,100):
        for k in range(3,501):
            D,X,H=boundary(2*k+4+s,k)
            assert H>0 and D+X+H>0 and X+2*H>0,(k,s,'boundary')
            total+=1
    print('PASS: lambda>=1 sufficient boundary certificate, k=3..500 x 5 s-values:',total)
    if args.extended:
        total2=0
        for s in (0,1):
            for k in range(3,1001):
                D,X,H=boundary(2*k+4+s,k)
                assert H>0 and D+X+H>0 and X+2*H>0,(k,s,'extended boundary')
                total2+=1
        print('PASS: extended k=3..1000 x 2 s-values:',total2)
    # Compare independent full polynomial computation and the direct four-coefficient formula.
    independent=0
    for k in range(3,36):
        for s in (0,1,10):
            n=2*k+4+s
            P=mul(p(n,k),p(n,k)); Q=mul(p(n,k-1),p(n,k+1))
            D,X,H=boundary(n,k)
            assert D==M(P,Q,k)
            assert H==M(P,Q,k-1)
            assert X==at(P,k-1)*at(Q,k+1)-at(P,k+1)*at(Q,k-1)
            for L in ([1,1],[1,3],[1,4]):
                assert M(mul(L,P),mul(L,Q),k)==D+L[1]*X+L[1]**2*H
            K=mul(z(k+2),z(k+2))
            A=mul(mul(z(k+1),z(k+3)),P)
            B=mul(K,Q)
            assert all(M(A,B,r)==M(mul(K,P),B,r) for r in range(k+1))
            assert all(M(A,B,r)>0 for r in range(k+1))
            independent+=1
    print('PASS: direct boundary vs independent full-convolution route:',independent)
    cb_count=0
    for k in range(3,12):
        n=2*k+4
        P=mul(p(n,k),p(n,k)); Q=mul(p(n,k-1),p(n,k+1))
        H=mul(z(k+2),z(k+2))
        HP=mul(H,P); HQ=mul(H,Q)
        for r in range(k+1):
            rhs=0
            for i in range(r+2):
                for j in range(i+1,r+2):
                    w=at(H,r-i)*at(H,r+1-j)-at(H,r-j)*at(H,r+1-i)
                    assert w>=0
                    rhs+=(at(P,i)*at(Q,j)-at(P,j)*at(Q,i))*w
            assert rhs==M(HP,HQ,r)
            cb_count+=1
    print('PASS: exact Cauchy-Binet minor expansion and PF2 weights:',cb_count)
    D,X,H=boundary(26,11)
    assert D==-353710041692430975552
    assert D+X+H==186373434723585797495808
    print('PASS: negative control k=11,n=26, unsmoothed negative / smoothed positive')
    print('UNPROVEN: all-parameter interior raw prefix and linear-smoothed boundary inequalities')

if __name__=='__main__':main()
