#!/usr/bin/env python3
"""Exact Newton-certificate verifier for finite k ranges, all integer n>=2k+4.

The theorem: when all delta^j f(0)>=0 for j<=d and polynomial degree <=d,
then f(s)>=0 for every INTEGER s>=0 via binomial basis. This verifier
proves its stated finite *k* range with no n upper bound. It does NOT prove
all-k positivity, nor the source's global conjecture.
"""
from math import comb
import argparse

def C(a,b):
    return comb(a,b) if 0 <= b <= a else 0

def p_coeff(n,k):
    return [C(k+2-j,j)*C(n-k-2+j,k) for j in range((k+2)//2+1)]

def coeff_product(a,b,stop):
    return [sum(a[i]*b[r-i] for i in range(max(0,r+1-len(b)),min(r+1,len(a))))
            for r in range(stop+1)]

def forward_coefficients(values):
    a=list(values);out=[]
    while a:
        out.append(a[0]);a=[a[i+1]-a[i] for i in range(len(a)-1)]
    return out

def check_k(k):
    row_values=[[] for _ in range(k)]
    boundary=[[] for _ in range(3)]
    for s in range(4*k+2):
        n=2*k+4+s
        x=p_coeff(n,k)
        P=coeff_product(x,x,k+1)
        Q=coeff_product(p_coeff(n,k-1),p_coeff(n,k+1),k+1)
        for r in range(k):
            row_values[r].append(P[r]*Q[r+1]-P[r+1]*Q[r])
        D=P[k]*Q[k+1]-P[k+1]*Q[k]
        X=P[k-1]*Q[k+1]-P[k+1]*Q[k-1]
        H=P[k-1]*Q[k]-P[k]*Q[k-1]
        for dest,val in zip(boundary,(H,D+X+H,X+2*H)):
            dest.append(val)
    positive=zeros=0
    for label,seq in ([('raw-M-'+str(r),v) for r,v in enumerate(row_values)] +
                      [(name,v) for name,v in zip(('H','J(1)','Jprime(1)'),boundary)]):
        coeff=forward_coefficients(seq)
        assert len(coeff)==4*k+2
        assert coeff[-1]==0,('degree',k,label)
        assert coeff[0]>0,('constant',k,label)
        for j,v in enumerate(coeff[:-1]):
            assert v>=0,('negative',k,label,j)
            positive+=v>0;zeros+=v==0
    return positive,zeros

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--k-start',type=int,default=3)
    ap.add_argument('--k-end',type=int,default=30)
    args=ap.parse_args()
    if args.k_start<3 or args.k_end<args.k_start:
        ap.error('require 3<=k-start<=k-end')
    positive=zeros=0
    for k in range(args.k_start,args.k_end+1):
        a,b=check_k(k)
        positive+=a; zeros+=b
    raw=sum(k*(4*k+1) for k in range(args.k_start,args.k_end+1))
    boundary=sum(3*(4*k+1) for k in range(args.k_start,args.k_end+1))
    assert positive+zeros==raw+boundary
    print('PASS exact Newton coefficients, k=%d..%d'%(args.k_start,args.k_end))
    print('RAW_PREFIX_COEFFICIENTS',raw)
    print('BOUNDARY_COEFFICIENTS',boundary)
    print('POSITIVE',positive,'ZERO',zeros,'NEGATIVE',0)
    print('CERTIFIED: all integer n>=2k+4 and all 0<=r<=k for the specified k range, conditional factor-transfer discharged.')
    print('UNPROVEN: all integer k>=3; global original u=1 log-concavity.')

if __name__=='__main__':main()
