#!/usr/bin/env python3
"""Independent direct full-polynomial convolution for original minors.

No one-factor reduction or Newton finite differences are used. Finite
checks only: NOT an all-n proof, and distinct from full Newton certificate.
"""
from math import comb

def c(a,b): return comb(a,b) if 0 <= b <= a else 0

def add(a,b):
    v=[0]*max(len(a),len(b))
    for j,x in enumerate(a):v[j]+=x
    for j,x in enumerate(b):v[j]+=x
    return v

def shift(a): return [0]+a

def z(m):
    prevprev=[1];prev=[1]
    for _ in range(2,m+1):
        now=add(prev,shift(prevprev))
        prevprev,prev=prev,now
    return prev

def p(n,k):
    match=z(k+2)
    return [v*c(n-k-2+j,k) for j,v in enumerate(match)]

def mul(a,b):
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]+=x*y
    return out

def get(a,i): return a[i] if 0<=i<len(a) else 0

def main():
    count=0
    for k in range(3,45):
        for s in list(range(25))+[10**9,10**15]:
            n=2*k+4+s
            a=mul(mul(z(k+1),z(k+3)),mul(p(n,k),p(n,k)))
            b=mul(mul(z(k+2),z(k+2)),mul(p(n,k-1),p(n,k+1)))
            for r in range(k+1):
                minor=get(a,r)*get(b,r+1)-get(a,r+1)*get(b,r)
                assert minor>0,(k,n,r,minor)
                count+=1
    print('PASS: independent direct FULL-polynomial minors:',count,
          'strictly positive, k=3..44, s=0..24, 10^9, 10^15')
    print('LIMITATION: these are sampled n; all-n theorem uses separate Newton certificate.')
if __name__=='__main__':main()
