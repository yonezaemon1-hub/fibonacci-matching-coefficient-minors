#!/usr/bin/env python3
"""Independent, standard-library-only verification of the coefficient formula.

Checks p_{n,k}(1) against the coefficient recurrence from Elizalde,
Rivera Jr., and Zhuang's Theorem 3.5 (rational generating function),
and against brute-force pattern avoidance for n<=8. This is a finite
cross-check; the analytic rational-identity derivation is in PROOF_NOTE.
"""
from itertools import permutations, combinations
from math import comb

def C(n, r):
    return comb(n, r) if 0 <= r <= n else 0

def formula(n, k):
    if n == 0 and k == 0:
        return 1
    return sum(C(k+2-j, j)*C(n-k-2+j, k)
               for j in range((k+2)//2 + 1))

def add(*args):
    v=[0]*max(map(len,args))
    for p in args:
        for i,a in enumerate(p): v[i]+=a
    return v

def scalar(p, a): return [a*x for x in p]

def shift(p, j): return [0]*j + list(p)

def gf_recurrence(N):
    a=[[1],[1],[2],[2,2]]
    for n in range(4,N+1):
        # 2 B_{n-1} - (1-t) B_{n-2} - t(1-t) B_{n-3}
        a.append(add(scalar(a[-1],2),scalar(a[-2],-1),
                     shift(a[-2],1),scalar(shift(a[-3],1),-1),
                     shift(a[-3],2)))
    return a[:N+1]

def brute(n):
    counts=[0]*(n+1)
    for pi in permutations(range(1,n+1)):
        if any((pi[i]<pi[j]<pi[h]) or (pi[i]<pi[h]<pi[j])
               for i,j,h in combinations(range(n),3)):
            continue
        bd=sum(pi[i]>pi[i+1]+1 for i in range(n-1))
        counts[bd]+=1
    return counts

def main():
    N=85
    GF=gf_recurrence(N)
    a=0
    for n,v in enumerate(GF):
        for k in range(n+1):
            actual=v[k] if k<len(v) else 0
            want=formula(n,k)
            assert actual==want,('GF',n,k,actual,want)
            a+=1
    print('PASS: independent Theorem 3.5 recurrence vs exact coefficient formula:',a,'cells, n<=',N)
    b=0
    for n in range(9):
        out=brute(n)
        for k in range(n+1):
            assert out[k]==formula(n,k),('BRUTE',n,k,out[k],formula(n,k))
            b+=1
    print('PASS: direct permutation avoidance and big descent count:',b,'cells, n<=8')
    print('STATUS: rational generating function identity proved in PROOF_NOTE; finite cross-check is additional evidence.')

if __name__=='__main__': main()
