No.61 candidate -- exact integer reproducibility (NOT RELEASED)
Author Ryutaro Yonezu; 2026-11-09; All rights reserved.

Quick checks (Python 3.10+ standard library):
  python verify_release_manifest.py
  python verify_logs_v024.py --k-end 180
  python verify_correspondence_v024.py
  python verify_newton_v023.py --k-start 3 --k-end 12
  python verify_direct_newton_v0241.py --k-start 3 --k-end 8

Complete exact Newton regeneration (computationally intensive):
  Windows PowerShell:
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_repro_windows.ps1 -Full
  Cross-platform: run verify_newton_v023.py over the 12 intervals
    3-50,51-80,81-100,101-110,111-120,121-122,123-130,
    131-140,141-150,151-160,161-170,171-180.

The saved 12 logs are checksums and comparison targets, not themselves
an independent recomputation. The command with -Full regenerates them.
Direct (reduction-free) Newton certificate is separately reproduced
by verify_direct_newton_v0241.py --k-start 3 --k-end 22.

Finite k<=180 only, n>=2k+4, minor indices r=0..k.
No assertion for all k and no resolution of Conjecture 4.6.
All rights reserved; no public release is authorized in this bundle.
