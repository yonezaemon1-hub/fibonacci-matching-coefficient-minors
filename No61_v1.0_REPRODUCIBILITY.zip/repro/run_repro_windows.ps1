# No.61 release-candidate repro, PowerShell 5.1, Python >= 3.10
param([switch]$Full)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$pycmd = Get-Command py -ErrorAction SilentlyContinue
if ($pycmd) { $interpreter = 'py'; $pre = @('-3') }
else {
    $p = Get-Command python -ErrorAction SilentlyContinue
    if (-not $p) { throw 'Python 3 not found' }
    $interpreter = 'python'; $pre = @()
}
function Run-Check([string[]] $ArgsList) {
    & $interpreter @pre @ArgsList
    if ($LASTEXITCODE -ne 0) { throw ('FAILED: ' + ($ArgsList -join ' ')) }
}
Run-Check @('verify_release_manifest.py')
Run-Check @('verify_logs_v024.py','--k-end','180')
Run-Check @('verify_correspondence_v024.py')
Run-Check @('verify_newton_v023.py','--k-start','3','--k-end','12')
Run-Check @('verify_direct_newton_v0241.py','--k-start','3','--k-end','8')
if ($Full) {
    $ranges = @(@(3,50),@(51,80),@(81,100),@(101,110),@(111,120),@(121,122),@(123,130),@(131,140),@(141,150),@(151,160),@(161,170),@(171,180))
    foreach ($range in $ranges) {
        Run-Check @('verify_newton_v023.py','--k-start',([string]$range[0]),'--k-end',([string]$range[1]))
    }
    Run-Check @('verify_v023.py')
    Write-Host 'PASS: No61 candidate FULL reproduction, k=3..180'
} else {
    Write-Host 'PASS: No61 candidate QUICK verification only (not all k)'
}
