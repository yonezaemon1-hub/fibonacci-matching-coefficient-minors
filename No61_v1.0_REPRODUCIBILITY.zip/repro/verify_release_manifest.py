#!/usr/bin/env python3
"""Check the complete public-candidate reproducibility inventory and SHA256."""
from pathlib import Path
import hashlib, re
root=Path(__file__).resolve().parent
lines=(root/'SHA256SUMS.txt').read_text('utf-8').splitlines()
expected={}
for line in lines:
    m=re.fullmatch(r'([0-9a-f]{64})  ([^/\\]+)',line)
    assert m, ('invalid manifest',line)
    digest,name=m.groups();assert name not in expected
    expected[name]=digest
actual={p.name for p in root.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt'}
assert actual==set(expected),(actual-set(expected),set(expected)-actual)
for name,digest in expected.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest, name
print('PASS: release-candidate manifest',len(expected),'files, all SHA256 match')
